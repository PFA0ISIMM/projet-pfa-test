<?php
session_start();
require('config.php');

$univ_id = (int)($_GET['univ'] ?? 0);

// All universities with stats
$universites = $conn->query("
    SELECT u.*, g.nom as gouvernorat, g.region,
           COUNT(DISTINCT f.id)    as nb_filieres,
           COUNT(DISTINCT inst.id) as nb_institutions
    FROM universites u
    LEFT JOIN gouvernorats g   ON u.gouvernorat_id = g.id
    LEFT JOIN institutions inst ON inst.universite_id = u.id
    LEFT JOIN filieres f       ON f.universite_id = u.id AND f.statut='active'
    GROUP BY u.id
    ORDER BY nb_filieres DESC
")->fetch_all(MYSQLI_ASSOC);

// If a specific university is selected
$univ = null;
$institutions = [];
$filieres_univ = [];

if ($univ_id) {
    $univ = $conn->query("
        SELECT u.*, g.nom as gouvernorat, g.region
        FROM universites u LEFT JOIN gouvernorats g ON u.gouvernorat_id=g.id
        WHERE u.id=$univ_id
    ")->fetch_assoc();

    if ($univ) {
        $institutions = $conn->query("
            SELECT inst.*, g.nom as gouvernorat,
                   COUNT(f.id) as nb_filieres
            FROM institutions inst
            LEFT JOIN gouvernorats g ON inst.gouvernorat_id=g.id
            LEFT JOIN filieres f ON f.institution_id=inst.id AND f.statut='active'
            WHERE inst.universite_id=$univ_id
            GROUP BY inst.id
            ORDER BY inst.type, inst.nom
        ")->fetch_all(MYSQLI_ASSOC);

        $filieres_univ = $conn->query("
            SELECT f.*, inst.nom as inst_nom, inst.sigle as inst_sigle
            FROM filieres f
            LEFT JOIN institutions inst ON f.institution_id=inst.id
            WHERE f.universite_id=$univ_id AND f.statut='active'
            ORDER BY f.score_min DESC LIMIT 12
        ")->fetch_all(MYSQLI_ASSOC);
    }
}

$INST_TYPE_LABELS = [
    'faculte'            => ['label'=>'Faculté',          'icon'=>'🏛️', 'color'=>'chip-red'],
    'institut_superieur' => ['label'=>'Institut Supérieur','icon'=>'🎓', 'color'=>'chip-blue'],
    'ecole'              => ['label'=>'Grande École',      'icon'=>'⭐', 'color'=>'chip-gold'],
    'centre_prep'        => ['label'=>'Centre Prépa',      'icon'=>'📚', 'color'=>'chip-green'],
    'autre'              => ['label'=>'Établissement',     'icon'=>'📋', 'color'=>'chip-gray'],
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $univ ? htmlspecialchars($univ['nom']).' — ' : '' ?>Universités — EduGuide TN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .univ-card {
            background:white;border-radius:var(--radius-lg);border:1px solid var(--gray-mid);
            padding:24px;box-shadow:var(--shadow-sm);text-decoration:none;color:inherit;
            display:block;transition:all var(--transition);
        }
        .univ-card:hover { transform:translateY(-5px);box-shadow:var(--shadow-md);border-color:var(--red); }
        .univ-card .univ-sigle {
            font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--red);margin-bottom:4px;
        }
        .univ-card .univ-name { font-size:14px;font-weight:600;color:var(--text);margin-bottom:10px; }
        .univ-stats { display:flex;gap:16px;margin-top:14px;padding-top:14px;border-top:1px solid var(--gray-mid); }
        .univ-stat { text-align:center; }
        .univ-stat .num { font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--navy); }
        .univ-stat .lbl { font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:600; }

        .inst-card {
            background:white;border-radius:var(--radius-md);border:1px solid var(--gray-mid);
            padding:18px 20px;display:flex;align-items:center;gap:16px;
            transition:all var(--transition);
        }
        .inst-card:hover { border-color:var(--red);box-shadow:var(--shadow-sm); }
        .inst-type-dot {
            width:44px;height:44px;border-radius:var(--radius-sm);
            display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;
        }
    </style>
</head>
<body>
<?php require('nav.php'); ?>

<div class="detail-banner" style="padding:60px 60px 50px;">
    <div style="position:relative;z-index:1;max-width:1280px;margin:0 auto;">
        <div class="breadcrumb">
            <a href="index.php">Accueil</a><span class="sep">/</span>
            <?php if($univ): ?>
                <a href="universites.php">Universités</a><span class="sep">/</span>
                <span><?= htmlspecialchars($univ['sigle'] ?? $univ['nom']) ?></span>
            <?php else: ?>
                <span>Universités</span>
            <?php endif; ?>
        </div>
        <h1 style="font-family:var(--font-display);font-size:clamp(1.8rem,3.5vw,2.5rem);font-weight:700;color:white;margin-bottom:10px;">
            <?= $univ ? '🏛️ '.htmlspecialchars($univ['nom']) : '🏛️ Universités Tunisiennes' ?>
        </h1>
        <p style="color:rgba(255,255,255,0.6);">
            <?= $univ
                ? "Facultés, instituts supérieurs et grandes écoles · ".(count($institutions))." établissements"
                : count($universites)." universités publiques · ".array_sum(array_column($universites,'nb_filieres'))." filières" ?>
        </p>
    </div>
    <div style="position:absolute;inset:0;background:radial-gradient(circle at 30%,rgba(212,168,83,0.15),transparent 50%);pointer-events:none;"></div>
</div>

<div style="max-width:1280px;margin:0 auto;padding:50px 60px;">
    <?php if($univ): ?>
    <!-- ── VUE UNIVERSITÉ SPÉCIFIQUE ── -->
    <div style="display:grid;grid-template-columns:280px 1fr;gap:30px;align-items:start;">
        <!-- Sidebar info université -->
        <div>
            <div class="info-card" style="margin-bottom:20px;">
                <div style="text-align:center;padding:20px 0;">
                    <div style="font-family:var(--font-display);font-size:2rem;font-weight:700;color:var(--red);"><?= htmlspecialchars($univ['sigle']) ?></div>
                    <div style="font-size:13px;color:var(--gray-text);margin-top:4px;">Université publique tunisienne</div>
                </div>
                <div class="info-list">
                    <div class="info-row">
                        <div class="info-ico">📍</div>
                        <div><div style="font-size:11px;color:var(--gray-text);font-weight:700;text-transform:uppercase;">Siège</div>
                        <div style="font-size:13px;font-weight:600;"><?= htmlspecialchars($univ['gouvernorat']) ?> — <?= htmlspecialchars($univ['region']) ?></div></div>
                    </div>
                    <div class="info-row">
                        <div class="info-ico">🏛️</div>
                        <div><div style="font-size:11px;color:var(--gray-text);font-weight:700;text-transform:uppercase;">Établissements</div>
                        <div style="font-size:13px;font-weight:600;"><?= count($institutions) ?> facultés & instituts</div></div>
                    </div>
                    <div class="info-row">
                        <div class="info-ico">📚</div>
                        <div><div style="font-size:11px;color:var(--gray-text);font-weight:700;text-transform:uppercase;">Filières</div>
                        <div style="font-size:13px;font-weight:600;"><?= count($filieres_univ) ?>+ formations disponibles</div></div>
                    </div>
                </div>
                <?php if($univ['site_web']): ?>
                <a href="<?= htmlspecialchars($univ['site_web']) ?>" target="_blank"
                   class="btn btn-primary btn-full btn-sm" style="margin-top:4px;">
                    🌍 Site officiel
                </a>
                <?php endif; ?>
                <a href="filieres.php?univ=<?= $univ_id ?>" class="btn btn-outline btn-full btn-sm" style="margin-top:8px;">
                    📚 Toutes les filières
                </a>
            </div>
            <a href="universites.php" class="btn btn-dark btn-full btn-sm">← Toutes les universités</a>
        </div>

        <!-- Contenu principal -->
        <div>
            <!-- Institutions -->
            <h2 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--text);margin-bottom:20px;">
                🏛️ Facultés & Instituts Supérieurs
            </h2>
            <?php
            // Group by type
            $byType = [];
            foreach($institutions as $inst) {
                $byType[$inst['type']][] = $inst;
            }
            $typeOrder = ['faculte','ecole','centre_prep','institut_superieur','autre'];
            foreach($typeOrder as $type):
                if(empty($byType[$type])) continue;
                $tinfo = $INST_TYPE_LABELS[$type] ?? $INST_TYPE_LABELS['autre'];
            ?>
            <div style="margin-bottom:28px;">
                <h3 style="display:flex;align-items:center;gap:8px;font-family:var(--font-display);font-size:1.1rem;font-weight:700;color:var(--text);margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid var(--gray-mid);">
                    <span><?= $tinfo['icon'] ?></span> <?= $tinfo['label'] ?>s
                    <span class="chip chip-gray" style="font-size:11px;margin-left:4px;"><?= count($byType[$type]) ?></span>
                </h3>
                <div style="display:flex;flex-direction:column;gap:10px;">
                    <?php foreach($byType[$type] as $inst): ?>
                    <div class="inst-card">
                        <div class="inst-type-dot" style="background:var(--gray-soft);"><?= $tinfo['icon'] ?></div>
                        <div style="flex:1;">
                            <div style="font-weight:700;color:var(--text);font-size:14px;margin-bottom:2px;">
                                <?= htmlspecialchars($inst['nom']) ?>
                            </div>
                            <div style="font-size:12px;color:var(--gray-text);display:flex;align-items:center;gap:10px;">
                                <?php if($inst['sigle']): ?><span class="chip chip-red" style="font-size:10px;padding:2px 8px;"><?= htmlspecialchars($inst['sigle']) ?></span><?php endif; ?>
                                <?php if($inst['gouvernorat']): ?><span>📍 <?= htmlspecialchars($inst['gouvernorat']) ?></span><?php endif; ?>
                                <?php if($inst['nb_filieres']): ?><span>📚 <?= $inst['nb_filieres'] ?> filière<?= $inst['nb_filieres']>1?'s':'' ?></span><?php endif; ?>
                            </div>
                        </div>
                        <a href="filieres.php?univ=<?= $univ_id ?>&inst=<?= $inst['id'] ?>"
                           class="btn btn-sm btn-outline" style="white-space:nowrap;flex-shrink:0;">
                            Voir →
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>

            <!-- Aperçu filières -->
            <?php if(!empty($filieres_univ)): ?>
            <h2 style="font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--text);margin:32px 0 18px;">
                📚 Aperçu des filières
            </h2>
            <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:20px;">
                <?php foreach($filieres_univ as $f): ?>
                <a href="detail.php?id=<?= $f['id'] ?>" style="display:flex;align-items:center;gap:14px;padding:14px 18px;background:white;border:1px solid var(--gray-mid);border-radius:var(--radius-md);text-decoration:none;transition:all var(--transition);"
                   onmouseover="this.style.borderColor='var(--red)';this.style.boxShadow='var(--shadow-sm)'"
                   onmouseout="this.style.borderColor='var(--gray-mid)';this.style.boxShadow='none'">
                    <span style="font-size:20px;"><?= $f['icon'] ?? '🎓' ?></span>
                    <div style="flex:1;">
                        <div style="font-weight:600;color:var(--text);font-size:14px;"><?= htmlspecialchars($f['titre']) ?></div>
                        <div style="font-size:12px;color:var(--gray-text);">
                            <?php if($f['inst_nom']): ?><?= htmlspecialchars(mb_substr($f['inst_nom'],0,50)) ?><?php endif; ?>
                        </div>
                    </div>
                    <div style="text-align:right;flex-shrink:0;">
                        <div style="font-family:var(--font-display);font-size:1.1rem;font-weight:700;color:var(--red);"><?= number_format($f['score_min'],1) ?></div>
                        <div style="font-size:10px;color:var(--gray-text);">/ 210</div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            <a href="filieres.php?univ=<?= $univ_id ?>" class="btn btn-outline">Voir toutes les filières →</a>
            <?php endif; ?>
        </div>
    </div>

    <?php else: ?>
    <!-- ── VUE LISTE UNIVERSITÉS ── -->
    <div class="section-header" style="margin-bottom:40px;">
        <span class="section-tag">Enseignement supérieur tunisien</span>
        <h2 class="section-title">Les universités publiques de Tunisie</h2>
        <p class="section-sub">Chaque université regroupe plusieurs facultés et instituts supérieurs. Cliquez pour explorer les établissements et filières.</p>
    </div>

    <div class="grid-3" style="gap:24px;">
        <?php foreach($universites as $u): ?>
        <a href="universites.php?univ=<?= $u['id'] ?>" class="univ-card">
            <div style="display:flex;align-items:center;gap:14px;margin-bottom:12px;">
                <div style="width:50px;height:50px;background:linear-gradient(135deg,var(--navy),var(--navy-mid));border-radius:var(--radius-md);display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:1.1rem;font-weight:700;color:white;flex-shrink:0;">
                    <?= mb_substr($u['sigle'],0,2) ?>
                </div>
                <div>
                    <div class="univ-sigle" style="font-size:1rem;"><?= htmlspecialchars($u['sigle']) ?></div>
                    <div style="font-size:11px;color:var(--gray-text);">📍 <?= htmlspecialchars($u['gouvernorat'] ?? '') ?> — <?= htmlspecialchars($u['region'] ?? '') ?></div>
                </div>
            </div>
            <div class="univ-name" style="font-size:13px;"><?= htmlspecialchars($u['nom']) ?></div>
            <div class="univ-stats">
                <div class="univ-stat">
                    <div class="num"><?= $u['nb_institutions'] ?></div>
                    <div class="lbl">Établissements</div>
                </div>
                <div class="univ-stat">
                    <div class="num"><?= $u['nb_filieres'] ?></div>
                    <div class="lbl">Filières</div>
                </div>
                <?php if($u['site_web']): ?>
                <div style="margin-left:auto;align-self:center;">
                    <span class="chip chip-blue" style="font-size:10px;">Site web →</span>
                </div>
                <?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php require('footer.php'); ?>
</body>
</html>