<?php
session_start();
require('config.php');
requireLogin();

$uid  = intval($_SESSION['user_id']);
$user = $conn->query("SELECT * FROM utilisateurs WHERE id=$uid")->fetch_assoc();

// Favoris
$favoris = $conn->query("
    SELECT f.*, u.sigle as univ_sigle, inst.nom as inst_nom, inst.sigle as inst_sigle,
           g.nom as gouvernorat, c.created_at as date_ajout
    FROM candidatures c
    JOIN filieres f     ON c.filiere_id     = f.id
    LEFT JOIN universites u    ON f.universite_id  = u.id
    LEFT JOIN institutions inst ON f.institution_id = inst.id
    LEFT JOIN gouvernorats g   ON u.gouvernorat_id  = g.id
    WHERE c.utilisateur_id = $uid
    ORDER BY c.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

// Mise à jour profil
$success_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $prenom     = esc($conn, $_POST['prenom']   ?? '');
    $nom        = esc($conn, $_POST['nom']       ?? '');
    $serie      = esc($conn, $_POST['serie']     ?? '');
    $score      = (float)str_replace(',','.',($_POST['score_bac'] ?? ''));
    $gouvernorat= esc($conn, $_POST['gouvernorat'] ?? '');

    if ($score < 0 || $score > 210) $score = 0;

    $conn->query("UPDATE utilisateurs SET
        prenom='$prenom', nom='$nom', serie='$serie',
        score_bac=" . ($score > 0 ? $score : 'NULL') . ",
        gouvernorat='$gouvernorat'
        WHERE id=$uid");

    $_SESSION['prenom'] = $_POST['prenom'];
    $_SESSION['nom']    = $_POST['nom'];
    setFlash('success', 'Profil mis à jour avec succès ! ✅');
    redirect('mon-compte.php');
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Compte — EduGuide TN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .account-layout { display:grid;grid-template-columns:280px 1fr;gap:30px;padding:50px 60px;max-width:1240px;margin:0 auto; }
        .tab-btn { display:block;width:100%;text-align:left;padding:12px 16px;border-radius:var(--radius-md);font-size:14px;font-weight:600;color:var(--text);background:transparent;border:none;cursor:pointer;transition:all var(--transition); }
        .tab-btn:hover,.tab-btn.active { background:var(--red);color:white; }
        .tab-content { display:none; }
        .tab-content.show { display:block; }
        @media(max-width:900px){.account-layout{grid-template-columns:1fr;padding:30px 20px;}}
    </style>
</head>
<body>
<?php require('nav.php'); ?>

<div class="detail-banner" style="padding:50px 60px;">
    <div style="position:relative;z-index:1;max-width:1240px;margin:0 auto;">
        <div class="breadcrumb"><a href="index.php">Accueil</a><span class="sep">/</span><span>Mon Compte</span></div>
        <h1 style="font-family:var(--font-display);font-size:2rem;font-weight:700;color:white;margin-bottom:8px;">
            👤 Bonjour, <?= htmlspecialchars($user['prenom']) ?> !
        </h1>
        <p style="color:rgba(255,255,255,0.6);">Gérez votre profil · <?= count($favoris) ?> filière<?= count($favoris)>1?'s':'' ?> favorite<?= count($favoris)>1?'s':'' ?></p>
    </div>
</div>

<div class="account-layout">
    <!-- Sidebar navigation -->
    <aside>
        <div class="info-card" style="padding:20px 14px;">
            <!-- Avatar -->
            <div style="text-align:center;margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid var(--gray-mid);">
                <div style="width:70px;height:70px;background:linear-gradient(135deg,var(--red),var(--navy));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 12px;">
                    <?= mb_strtoupper(mb_substr($user['prenom'],0,1)) ?>
                </div>
                <div style="font-family:var(--font-display);font-size:1rem;font-weight:700;color:var(--text);">
                    <?= htmlspecialchars($user['prenom'].' '.$user['nom']) ?>
                </div>
                <div style="font-size:12px;color:var(--gray-text);"><?= htmlspecialchars($user['email']) ?></div>
                <?php if($user['score_bac']): ?>
                <div style="margin-top:10px;display:inline-block;background:var(--red-light);color:var(--red);font-weight:700;font-size:13px;padding:4px 14px;border-radius:50px;">
                    🎓 <?= number_format($user['score_bac'],1) ?> / 210
                </div>
                <?php endif; ?>
            </div>

            <!-- Menu -->
            <button class="tab-btn active" onclick="showTab('favoris',this)">❤️ Mes favoris (<?= count($favoris) ?>)</button>
            <button class="tab-btn" onclick="showTab('profil',this)">✏️ Modifier mon profil</button>
            <button class="tab-btn" onclick="showTab('score',this)">📊 Calculer mon score</button>
            <div style="margin-top:16px;padding-top:16px;border-top:1px solid var(--gray-mid);">
                <a href="recherche.php" class="btn btn-outline btn-sm btn-full" style="margin-bottom:8px;">🔍 Rechercher une filière</a>
                <a href="chatbot.php"   class="btn btn-dark btn-sm btn-full" style="margin-bottom:8px;">🤖 Chatbot IA</a>
                <a href="deconnexion.php" class="btn btn-sm btn-full" style="background:#FEF2F2;color:var(--red);font-weight:700;">↩ Déconnexion</a>
            </div>
        </div>
    </aside>

    <!-- Contenu -->
    <main>
        <?php getFlash(); ?>

        <!-- FAVORIS -->
        <div class="tab-content show" id="tab-favoris">
            <h2 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--text);margin-bottom:20px;">❤️ Mes filières favorites</h2>
            <?php if(empty($favoris)): ?>
            <div style="text-align:center;padding:60px 40px;background:white;border-radius:var(--radius-lg);border:1px solid var(--gray-mid);">
                <div style="font-size:48px;margin-bottom:14px;">💔</div>
                <h3 style="font-family:var(--font-display);font-size:1.3rem;color:var(--text);margin-bottom:8px;">Aucun favori pour l'instant</h3>
                <p style="color:var(--gray-text);margin-bottom:20px;">Explorez les filières et ajoutez-les à vos favoris pour les retrouver ici.</p>
                <a href="filieres.php" class="btn btn-primary">Parcourir les filières →</a>
            </div>
            <?php else: ?>
            <div style="display:flex;flex-direction:column;gap:14px;">
                <?php foreach($favoris as $f): ?>
                <div style="display:flex;align-items:center;gap:16px;padding:18px 20px;background:white;border-radius:var(--radius-lg);border:1px solid var(--gray-mid);box-shadow:var(--shadow-sm);transition:all var(--transition);"
                     onmouseover="this.style.boxShadow='var(--shadow-md)'" onmouseout="this.style.boxShadow='var(--shadow-sm)'">
                    <div class="card-top <?= htmlspecialchars($f['couleur_classe']??'ct-def') ?>" style="width:56px;height:56px;border-radius:var(--radius-md);flex-shrink:0;display:flex;align-items:center;justify-content:center;">
                        <span style="font-size:22px;"><?= $f['icon']??'🎓' ?></span>
                    </div>
                    <div style="flex:1;">
                        <div style="font-weight:700;color:var(--text);font-size:15px;margin-bottom:3px;"><?= htmlspecialchars($f['titre']) ?></div>
                        <div style="font-size:12px;color:var(--gray-text);margin-bottom:4px;">
                            🏛️ <?= htmlspecialchars($f['inst_nom'] ? mb_substr($f['inst_nom'],0,50).'…' : ($f['univ_sigle']??'N/A')) ?>
                            <?php if($f['gouvernorat']): ?> · 📍 <?= htmlspecialchars($f['gouvernorat']) ?><?php endif; ?>
                        </div>
                        <div style="font-size:11px;color:var(--gray-text);">Ajouté le <?= date('d/m/Y', strtotime($f['date_ajout'])) ?></div>
                    </div>
                    <div style="text-align:right;flex-shrink:0;">
                        <div style="font-family:var(--font-display);font-size:1.3rem;font-weight:700;color:var(--red);"><?= number_format($f['score_min'],1) ?></div>
                        <div style="font-size:10px;color:var(--gray-text);margin-bottom:8px;">/ 210 pts</div>
                        <a href="detail.php?id=<?= $f['id'] ?>" class="btn btn-outline btn-sm">Voir →</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- PROFIL -->
        <div class="tab-content" id="tab-profil">
            <h2 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--text);margin-bottom:20px;">✏️ Modifier mon profil</h2>
            <div style="background:white;border-radius:var(--radius-lg);padding:30px;border:1px solid var(--gray-mid);">
                <form method="POST">
                    <div class="form-row-2">
                        <div class="form-group">
                            <label>Prénom</label>
                            <input type="text" name="prenom" value="<?= htmlspecialchars($user['prenom']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Nom</label>
                            <input type="text" name="nom" value="<?= htmlspecialchars($user['nom']) ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Adresse e-mail (non modifiable)</label>
                        <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled style="opacity:0.6;cursor:not-allowed;">
                    </div>
                    <div style="background:var(--gray-soft);border-radius:var(--radius-md);padding:20px;margin-bottom:18px;">
                        <p style="font-size:12px;font-weight:700;color:var(--gray-text);text-transform:uppercase;letter-spacing:0.6px;margin-bottom:14px;">🎓 Profil baccalauréat</p>
                        <div class="form-row-2">
                            <div class="form-group" style="margin-bottom:0;">
                                <label>Section du bac</label>
                                <select name="serie">
                                    <option value="">-- Choisir --</option>
                                    <?php
                                    $secs = ['Mathématiques','Sciences Expérimentales','Sciences Techniques','Informatique','Économie & Gestion','Lettres','Sport'];
                                    foreach($secs as $s): ?>
                                    <option value="<?= $s ?>" <?= $user['serie']===$s?'selected':'' ?>><?= $s ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group" style="margin-bottom:0;">
                                <label>Score du bac (sur 210)</label>
                                <input type="number" name="score_bac" step="0.1" min="0" max="210"
                                       placeholder="Ex: 145.5"
                                       value="<?= $user['score_bac'] ? number_format($user['score_bac'],1) : '' ?>">
                            </div>
                        </div>
                        <div class="form-group" style="margin-top:14px;margin-bottom:0;">
                            <label>Gouvernorat</label>
                            <select name="gouvernorat">
                                <option value="">-- Choisir --</option>
                                <?php
                                $govs = ['Tunis','Ariana','Ben Arous','Manouba','Nabeul','Zaghouan','Bizerte','Béja','Jendouba','Le Kef','Siliana','Kairouan','Kasserine','Sidi Bouzid','Sousse','Monastir','Mahdia','Sfax','Gafsa','Tozeur','Kébili','Gabès','Médenine','Tataouine'];
                                foreach($govs as $g): ?>
                                <option value="<?= $g ?>" <?= $user['gouvernorat']===$g?'selected':'' ?>><?= $g ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-primary">
                        💾 Enregistrer les modifications
                    </button>
                </form>
            </div>
        </div>

        <!-- CALCULATEUR SCORE -->
        <div class="tab-content" id="tab-score">
            <h2 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--text);margin-bottom:20px;">📊 Calculer mon score d'orientation</h2>
            <div style="background:white;border-radius:var(--radius-lg);padding:30px;border:1px solid var(--gray-mid);">
                <p style="color:var(--gray-text);margin-bottom:24px;">Entrez vos notes du bac (sur 20) pour estimer votre score total selon les différentes formules.</p>

                <div class="form-row-2" style="margin-bottom:18px;">
                    <div class="form-group"><label>Note Générale (FG) / 20</label><input type="number" id="fg" step="0.001" min="0" max="20" placeholder="Ex: 15.250" oninput="calcScore()"></div>
                    <div class="form-group"><label>Note Mathématiques (M) / 20</label><input type="number" id="nm" step="0.001" min="0" max="20" placeholder="Ex: 16.000" oninput="calcScore()"></div>
                    <div class="form-group"><label>Note Sciences (SVT/SP) / 20</label><input type="number" id="ns" step="0.001" min="0" max="20" placeholder="Ex: 14.500" oninput="calcScore()"></div>
                    <div class="form-group"><label>Note Arabe (AR) / 20</label><input type="number" id="nar" step="0.001" min="0" max="20" placeholder="Ex: 13.000" oninput="calcScore()"></div>
                    <div class="form-group"><label>Note Anglais (ANG) / 20</label><input type="number" id="nang" step="0.001" min="0" max="20" placeholder="Ex: 14.000" oninput="calcScore()"></div>
                    <div class="form-group"><label>Note Informatique (Info) / 20</label><input type="number" id="ninfo" step="0.001" min="0" max="20" placeholder="Ex: 15.000" oninput="calcScore()"></div>
                </div>

                <div id="resultats" style="display:none;">
                    <h3 style="font-family:var(--font-display);font-size:1.1rem;font-weight:700;color:var(--text);margin-bottom:14px;">🎯 Vos scores estimés :</h3>
                    <div id="scores-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;"></div>
                    <div style="margin-top:18px;padding:14px;background:var(--blue-light);border-radius:var(--radius-md);">
                        <p style="font-size:12px;color:var(--blue);">⚠️ Ces scores sont estimatifs. Le score officiel est calculé selon le barème exact du Ministère. Consultez le guide officiel pour plus de précisions.</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php require('footer.php'); ?>

<script>
function showTab(name, btn) {
    document.querySelectorAll('.tab-content').forEach(t=>t.classList.remove('show'));
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.getElementById('tab-'+name).classList.add('show');
    btn.classList.add('active');
}

function calcScore() {
    const fg   = parseFloat(document.getElementById('fg').value)   || 0;
    const m    = parseFloat(document.getElementById('nm').value)    || 0;
    const s    = parseFloat(document.getElementById('ns').value)    || 0;
    const ar   = parseFloat(document.getElementById('nar').value)   || 0;
    const ang  = parseFloat(document.getElementById('nang').value)  || 0;
    const info = parseFloat(document.getElementById('ninfo').value) || 0;

    if(!fg) return;

    const formulas = [
        { label:'Mathématiques (FG+M)', score: fg+m, domaine:'Ingénierie, Sciences' },
        { label:'Sciences (FG+SVT)',    score: fg+s, domaine:'Médecine, Agronomie' },
        { label:'Arabe (FG+AR)',        score: fg+ar, domaine:'Lettres & Langues' },
        { label:'Anglais (FG+ANG)',     score: fg+ang, domaine:'Langues étrangères' },
        { label:'(FG+M+SVT)/2',         score: fg+(m+s)/2, domaine:'Médecine, Sciences' },
        { label:'(FG+M+SP+Info)/3',     score: fg+(m+s+info)/3, domaine:'Informatique, Réseaux' },
        { label:'(FG+M+GEST)/2',        score: fg+(m+0)/2, domaine:'Économie, Gestion' },
    ];

    const grid = document.getElementById('scores-grid');
    grid.innerHTML = '';
    formulas.forEach(f => {
        const s10 = Math.min(f.score*10.5/2, 210);
        const color = s10 >= 160 ? 'var(--red)' : s10 >= 120 ? '#7A5A18' : 'var(--blue)';
        grid.innerHTML += `<div style="padding:14px;background:var(--gray-soft);border-radius:var(--radius-md);border:1px solid var(--gray-mid);">
            <div style="font-size:11px;font-weight:700;color:var(--gray-text);text-transform:uppercase;margin-bottom:4px;">${f.label}</div>
            <div style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:${color};">${f.score.toFixed(2)}</div>
            <div style="font-size:10px;color:var(--gray-text);">≈ ${s10.toFixed(0)}/210 · ${f.domaine}</div>
        </div>`;
    });
    document.getElementById('resultats').style.display = 'block';
}
</script>
</body>
</html>