<?php /** footer.php — Footer commun EduGuide TN */ ?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-brand">
                <div class="logo" style="margin-bottom:16px;">
                    <div class="logo-mark" style="background:linear-gradient(135deg,#C8102E,#9B0B22);">E</div>
                    <span class="logo-text">Edu<span>Guide</span></span>
                </div>
                <p>La plateforme de référence pour l'orientation universitaire en Tunisie. Données officielles du guide 2025 — score sur 210 points. Trouvez la filière qui vous correspond.</p>
                <div class="footer-social">
                    <a href="#" aria-label="Facebook">📘</a>
                    <a href="#" aria-label="Instagram">📷</a>
                    <a href="#" aria-label="Twitter">🐦</a>
                    <a href="#" aria-label="YouTube">▶️</a>
                    <a href="#" aria-label="LinkedIn">💼</a>
                </div>
            </div>

            <div class="footer-col">
                <h4>Orientation</h4>
                <ul>
                    <li><a href="filieres.php">Toutes les filières</a></li>
                    <li><a href="recherche.php">Recherche avancée</a></li>
                    <li><a href="chatbot.php">Chatbot IA</a></li>
                    <li><a href="filieres.php?domaine=Médecine%2C+Pharmacie+%26+Odontologie">🩺 Médecine</a></li>
                    <li><a href="filieres.php?domaine=Sciences+Exactes+%26+Technologie">⚛️ Sciences & Techno</a></li>
                    <li><a href="filieres.php?domaine=Architecture+%26+Génie+Civil">🏗️ Ingénierie</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Universités</h4>
                <ul>
                    <li><a href="universites.php?univ=1">Université de Tunis</a></li>
                    <li><a href="universites.php?univ=2">Université de la Manouba</a></li>
                    <li><a href="universites.php?univ=5">Université de Sousse</a></li>
                    <li><a href="universites.php?univ=6">Université de Monastir</a></li>
                    <li><a href="universites.php?univ=7">Université de Sfax</a></li>
                    <li><a href="universites.php">Toutes les universités →</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>À propos</h4>
                <ul>
                    <li><a href="#">À propos d'EduGuide</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Mentions légales</a></li>
                    <li><a href="connexion.php">Connexion</a></li>
                    <li><a href="inscription.php">Inscription gratuite</a></li>
                    <?php if(isLoggedIn()): ?>
                    <li><a href="deconnexion.php" style="color:var(--gold);">↩ Déconnexion</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <span>© 2025 EduGuide TN — Tous droits réservés · Guide officiel دليل طاقة استيعاب 2025</span>
            <span style="display:flex;align-items:center;gap:6px;">
                🇹🇳 Fait avec passion pour les étudiants tunisiens
            </span>
        </div>
    </div>
</footer>