<?php
session_start();
require('config.php');

// Détruire la session
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}
session_destroy();

// Rediriger avec message flash (via GET pour page statique)
header('Location: index.php?deconnecte=1');
exit();