<?php
session_start();
require('config.php');

if (!isset($_SESSION['chat_id'])) {
    $_SESSION['chat_id'] = uniqid('chat_', true);
}
$chat_id = $_SESSION['chat_id'];
$user_id = isLoggedIn() ? intval($_SESSION['user_id']) : 'NULL';

// Charger historique
$messages = [];
$res = $conn->query("
    SELECT role, contenu, created_at
    FROM messages_chatbot
    WHERE session_id = '" . esc($conn,$chat_id) . "'
    ORDER BY created_at ASC LIMIT 50
");
if ($res) $messages = $res->fetch_all(MYSQLI_ASSOC);

// Message de bienvenue
if (empty($messages)) {
    $welcome = "Bonjour ! 👋 Je suis <strong>EduBot</strong>, votre assistant d'orientation universitaire EduGuide TN.<br><br>
                Pour vous aider au mieux, dites-moi :<br>
                • Votre <strong>score du bac (sur 210 points)</strong><br>
                • Votre <strong>section du bac</strong> (Maths, Sciences, Éco...)<br>
                • Votre <strong>domaine d'intérêt</strong> (médecine, informatique...)<br><br>
                Je suis là pour vous guider vers la meilleure filière ! 🎓🇹🇳";
    $conn->query("INSERT INTO messages_chatbot (utilisateur_id, session_id, role, contenu)
                  VALUES ($user_id, '" . esc($conn,$chat_id) . "', 'bot', '" . esc($conn,$welcome) . "')");
    $messages[] = ['role'=>'bot','contenu'=>$welcome,'created_at'=>date('Y-m-d H:i:s')];
}

// Traitement message entrant (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $userMsg = trim($_POST['message']);
    if (!empty($userMsg) && mb_strlen($userMsg) <= 500) {
        $safeMsg    = esc($conn,$userMsg);
        $conn->query("INSERT INTO messages_chatbot (utilisateur_id, session_id, role, contenu)
                      VALUES ($user_id, '" . esc($conn,$chat_id) . "', 'user', '$safeMsg')");

        $botReponse    = chatbotReponse($userMsg, $conn, isLoggedIn() ? $_SESSION : null);
        $safeBotReponse = esc($conn,$botReponse);
        $conn->query("INSERT INTO messages_chatbot (utilisateur_id, session_id, role, contenu)
                      VALUES ($user_id, '" . esc($conn,$chat_id) . "', 'bot', '$safeBotReponse')");

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])==='xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['reponse' => $botReponse]);
            exit();
        }
    }
    redirect('chatbot.php');
}

// Reset conversation
if (isset($_GET['reset'])) {
    $conn->query("DELETE FROM messages_chatbot WHERE session_id = '" . esc($conn,$chat_id) . "'");
    unset($_SESSION['chat_id']);
    redirect('chatbot.php');
}

$prefill = isset($_GET['prefill']) ? htmlspecialchars($_GET['prefill']) : '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot IA — EduGuide TN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .typing-indicator { display:none;gap:5px;align-items:center;padding:12px 15px;background:white;border-radius:16px;border-bottom-left-radius:4px;box-shadow:var(--shadow-sm);width:fit-content; }
        .typing-indicator.show { display:flex; }
        .typing-dot { width:7px;height:7px;background:var(--gray-text);border-radius:50%;animation:typingBounce 1.2s infinite; }
        .typing-dot:nth-child(2){animation-delay:0.2s;}.typing-dot:nth-child(3){animation-delay:0.4s;}
        @keyframes typingBounce{0%,60%,100%{transform:translateY(0);}30%{transform:translateY(-6px);}}
        .chatbot-msgs::-webkit-scrollbar{width:4px;}.chatbot-msgs::-webkit-scrollbar-thumb{background:var(--gray-mid);border-radius:2px;}
        .score-info-box {
            background:linear-gradient(135deg,var(--navy),var(--navy-mid));
            border-radius:var(--radius-md);padding:16px;margin-bottom:16px;
        }
        .score-info-box h4{font-family:var(--font-display);color:white;font-size:0.9rem;margin-bottom:10px;}
        .score-table{width:100%;border-collapse:collapse;}
        .score-table td{font-size:11px;padding:3px 0;color:rgba(255,255,255,0.7);}
        .score-table td:last-child{color:var(--gold);font-weight:700;text-align:right;}
    </style>
</head>
<body>
<?php require('nav.php'); ?>

<div class="detail-banner" style="padding:50px 60px;">
    <div style="position:relative;z-index:1;max-width:1240px;margin:0 auto;">
        <div class="breadcrumb"><a href="index.php">Accueil</a><span class="sep">/</span><span>Chatbot IA</span></div>
        <h1 style="font-family:var(--font-display);font-size:2.2rem;font-weight:700;color:white;margin-bottom:8px;">
            🤖 EduBot — Assistant d'Orientation IA
        </h1>
        <p style="color:rgba(255,255,255,0.6);">Entrez votre score (sur 210) · Obtenez des recommandations personnalisées instantanément</p>
    </div>
    <div style="position:absolute;inset:0;background:radial-gradient(circle at 30%,rgba(212,168,83,0.15),transparent 50%);pointer-events:none;"></div>
</div>

<section class="section section-alt" style="padding:40px 60px;">
    <div class="container" style="max-width:1200px;">
        <div style="display:grid;grid-template-columns:1fr 310px;gap:32px;align-items:start;">

            <!-- CHATBOT -->
            <div>
                <div class="chatbot-wrap">
                    <!-- Header -->
                    <div class="chatbot-hdr">
                        <div class="chatbot-ava">🤖</div>
                        <div class="chatbot-hdr-info">
                            <h3>EduBot — EduGuide TN</h3>
                            <p>Assistant d'orientation · Score sur 210 pts · Guide 2025</p>
                        </div>
                        <div class="online-dot" title="En ligne"></div>
                        <a href="chatbot.php?reset=1"
                           style="margin-left:12px;color:rgba(255,255,255,0.4);font-size:12px;transition:color 0.2s;"
                           onmouseover="this.style.color='white'" onmouseout="this.style.color='rgba(255,255,255,0.4)'"
                           title="Nouvelle conversation">🔄 Réinitialiser</a>
                    </div>

                    <!-- Suggestions -->
                    <div class="chatbot-sug" id="suggestions">
                        <span style="font-size:11px;color:var(--gray-text);font-weight:700;width:100%;margin-bottom:6px;">💡 Suggestions rapides :</span>
                        <button class="sug-chip" onclick="sendSuggestion(this)">Mon score est 162 en Maths</button>
                        <button class="sug-chip" onclick="sendSuggestion(this)">Filières médecine disponibles</button>
                        <button class="sug-chip" onclick="sendSuggestion(this)">Informatique et réseaux</button>
                        <button class="sug-chip" onclick="sendSuggestion(this)">Score minimum pour Cycle Ingénieur</button>
                        <button class="sug-chip" onclick="sendSuggestion(this)">Architecture à Tunis</button>
                        <button class="sug-chip" onclick="sendSuggestion(this)">Mes options avec 95 points</button>
                    </div>

                    <!-- Messages -->
                    <div class="chatbot-msgs" id="chatMessages">
                        <?php foreach($messages as $msg): ?>
                        <div class="msg <?= $msg['role'] ?>">
                            <div class="msg-ava <?= $msg['role']==='bot'?'bot-ava':'user-ava' ?>">
                                <?= $msg['role']==='bot'?'🤖':'👤' ?>
                            </div>
                            <div>
                                <div class="msg-bubble"><?= $msg['contenu'] ?></div>
                                <div style="font-size:10px;color:var(--gray-text);margin-top:3px;<?= $msg['role']==='user'?'text-align:right;':'' ?>">
                                    <?= date('H:i', strtotime($msg['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <div class="msg bot" id="typingMsg" style="display:none;">
                            <div class="msg-ava bot-ava">🤖</div>
                            <div class="typing-indicator show"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>
                        </div>
                    </div>

                    <!-- Input -->
                    <div class="chatbot-inp">
                        <input type="text" id="chatInput"
                               placeholder="Écrivez (Ex: Mon score est 145, je suis en Maths...)"
                               value="<?= $prefill ?>" maxlength="400" autocomplete="off">
                        <button onclick="sendMessage()" class="btn btn-primary btn-sm" id="sendBtn">➤</button>
                    </div>
                </div>
            </div>

            <!-- PANNEAU LATÉRAL -->
            <div style="display:flex;flex-direction:column;gap:18px;">

                <!-- Score sur 210 explication -->
                <div class="score-info-box">
                    <h4>📊 Score sur 210 pts</h4>
                    <table class="score-table">
                        <tr><td>Médecine / Chirurgie</td><td>≥ 185</td></tr>
                        <tr><td>Médecine Dentaire</td><td>≥ 175</td></tr>
                        <tr><td>Pharmacie</td><td>≥ 170</td></tr>
                        <tr><td>Cycle Ingénieur (ENIT)</td><td>≥ 180</td></tr>
                        <tr><td>Architecture (ENAU)</td><td>≥ 165</td></tr>
                        <tr><td>Informatique</td><td>≥ 150</td></tr>
                        <tr><td>Réseaux & Télécom</td><td>≥ 155</td></tr>
                        <tr><td>Sciences Économiques</td><td>≥ 90</td></tr>
                        <tr><td>Droit</td><td>≥ 85</td></tr>
                        <tr><td>Lettres & Langues</td><td>≥ 75</td></tr>
                    </table>
                    <div style="margin-top:10px;font-size:10px;color:rgba(255,255,255,0.4);">
                        Source : دليل طاقة استيعاب 2025
                    </div>
                </div>

                <!-- Profil utilisateur -->
                <?php if(isLoggedIn()): ?>
                <div class="info-card">
                    <h4 style="font-family:var(--font-display);font-size:1rem;color:var(--text);margin-bottom:14px;">👤 Votre profil</h4>
                    <?php
                    $userData = $conn->query("SELECT score_bac, serie FROM utilisateurs WHERE id=".intval($_SESSION['user_id']))->fetch_assoc();
                    ?>
                    <div style="font-size:14px;font-weight:600;color:var(--text);margin-bottom:6px;">
                        <?= htmlspecialchars(($_SESSION['prenom']??'').' '.($_SESSION['nom']??'')) ?>
                    </div>
                    <?php if($userData && $userData['score_bac']): ?>
                    <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
                        <span style="color:var(--gray-text);">Score bac</span>
                        <strong style="color:var(--red);"><?= number_format($userData['score_bac'],1) ?> / 210</strong>
                    </div>
                    <?php endif; ?>
                    <?php if($userData && $userData['serie']): ?>
                    <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:14px;">
                        <span style="color:var(--gray-text);">Section</span>
                        <strong><?= htmlspecialchars($userData['serie']) ?></strong>
                    </div>
                    <?php endif; ?>
                    <?php if($userData && $userData['score_bac']): ?>
                    <a href="recherche.php?score=<?= $userData['score_bac'] ?>" class="btn btn-primary btn-sm btn-full">
                        Voir mes filières compatibles →
                    </a>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <div class="info-card" style="text-align:center;">
                    <div style="font-size:32px;margin-bottom:10px;">🔐</div>
                    <p style="font-size:13px;color:var(--gray-text);margin-bottom:14px;">Connectez-vous pour accéder à votre profil personnalisé et vos filières favorites.</p>
                    <a href="connexion.php" class="btn btn-primary btn-sm btn-full" style="margin-bottom:8px;">Se connecter</a>
                    <a href="inscription.php" class="btn btn-outline btn-sm btn-full">Créer un compte</a>
                </div>
                <?php endif; ?>

                <!-- Liens rapides -->
                <div class="info-card">
                    <h4 style="font-family:var(--font-display);font-size:0.95rem;color:var(--text);margin-bottom:12px;">🔗 Liens rapides</h4>
                    <div style="display:flex;flex-direction:column;gap:8px;">
                        <a href="recherche.php" class="btn btn-outline btn-sm btn-full">🔍 Recherche avancée</a>
                        <a href="filieres.php"  class="btn btn-dark btn-sm btn-full">📚 Catalogue filières</a>
                        <a href="universites.php" class="btn btn-sm btn-full" style="background:var(--blue-light);color:var(--blue);font-weight:700;">🏛️ Universités</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require('footer.php'); ?>

<script>
const chatMessages = document.getElementById('chatMessages');
const chatInput    = document.getElementById('chatInput');
const typingMsg    = document.getElementById('typingMsg');
const sendBtn      = document.getElementById('sendBtn');

function scrollBottom() { chatMessages.scrollTop = chatMessages.scrollHeight; }
scrollBottom();

async function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;
    appendMessage('user', text, now());
    chatInput.value = '';
    sendBtn.disabled = true;
    document.getElementById('suggestions').style.display = 'none';
    typingMsg.style.display = 'flex';
    scrollBottom();
    try {
        const res  = await fetch('chatbot.php', {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},
            body:'message='+encodeURIComponent(text)
        });
        const data = await res.json();
        typingMsg.style.display = 'none';
        appendMessage('bot', data.reponse, now());
    } catch(e) {
        typingMsg.style.display = 'none';
        appendMessage('bot', '⚠️ Erreur de connexion. Veuillez réessayer.', now());
    }
    sendBtn.disabled = false;
    chatInput.focus();
}

function now() { return new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}); }

function appendMessage(role, content, time) {
    const isBot = role === 'bot';
    const el = document.createElement('div');
    el.className = 'msg ' + role;
    el.style.cssText = `display:flex;gap:10px;align-items:flex-end;max-width:84%;animation:msgIn 0.3s ease;${isBot?'':'flex-direction:row-reverse;margin-left:auto;'}`;
    el.innerHTML = `
      <div class="msg-ava ${isBot?'bot-ava':'user-ava'}" style="width:30px;height:30px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;">${isBot?'🤖':'👤'}</div>
      <div>
        <div class="msg-bubble" style="padding:11px 15px;border-radius:16px;font-size:14px;line-height:1.6;${isBot?'background:white;color:var(--text);box-shadow:var(--shadow-sm);border-bottom-left-radius:4px;':'background:var(--navy);color:white;border-bottom-right-radius:4px;'}">${content}</div>
        <div style="font-size:10px;color:var(--gray-text);margin-top:3px;${isBot?'':'text-align:right;'}">${time}</div>
      </div>`;
    chatMessages.insertBefore(el, typingMsg);
    scrollBottom();
}

function sendSuggestion(btn) { chatInput.value = btn.textContent; sendMessage(); }
chatInput.addEventListener('keydown', e => { if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage();} });
<?php if($prefill): ?>window.addEventListener('load', () => { setTimeout(sendMessage, 600); });<?php endif; ?>
</script>
</body>
</html>