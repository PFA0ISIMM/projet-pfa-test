<?php
session_start();
require('config.php');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$filiere = $conn->query("
    SELECT f.*,
           u.nom   as univ_nom,  u.sigle  as univ_sigle, u.site_web,
           u.type  as univ_type,
           inst.nom   as inst_nom,  inst.sigle  as inst_sigle,
           inst.type  as inst_type, inst.adresse as inst_adresse,
           inst.site_web as inst_web,
           g.nom   as gouvernorat, g.region
    FROM filieres f
    LEFT JOIN universites u     ON f.universite_id  = u.id
    LEFT JOIN institutions inst ON f.institution_id = inst.id
    LEFT JOIN gouvernorats g    ON u.gouvernorat_id  = g.id
    WHERE f.id = $id AND f.statut = 'active'
")->fetch_assoc();

if (!$filiere) redirect('filieres.php');

// Gestion favori
$isFavori = false;
if (isLoggedIn()) {
    $uid   = intval($_SESSION['user_id']);
    $check = $conn->query("SELECT id FROM candidatures WHERE utilisateur_id=$uid AND filiere_id=$id");
    $isFavori = $check->num_rows > 0;

    if (isset($_POST['toggle_favori'])) {
        if ($isFavori) {
            $conn->query("DELETE FROM candidatures WHERE utilisateur_id=$uid AND filiere_id=$id");
            setFlash('info', 'Filière retirée de vos favoris.');
        } else {
            $conn->query("INSERT INTO candidatures (utilisateur_id, filiere_id) VALUES ($uid, $id)");
            setFlash('success', 'Filière ajoutée à vos favoris ! ❤️');
        }
        redirect("detail.php?id=$id");
    }
}

// Filières similaires (même domaine, même institution si possible)
$similaires = $conn->query("
    SELECT f.*, u.sigle as univ_sigle, inst.sigle as inst_sigle
    FROM filieres f
    LEFT JOIN universites u     ON f.universite_id  = u.id
    LEFT JOIN institutions inst ON f.institution_id = inst.id
    WHERE f.domaine = '" . esc($conn,$filiere['domaine']) . "'
    AND f.id != $id AND f.statut = 'active'
    ORDER BY ABS(f.score_min - {$filiere['score_min']}) ASC
    LIMIT 3
")->fetch_all(MYSQLI_ASSOC);

$debouches = json_decode($filiere['debouches'] ?? '[]', true) ?: [];
$matieres  = json_decode($filiere['matieres']  ?? '[]', true) ?: [];
$niveau    = scoreNiveau($filiere['score_min']);

// Type libellé institution
$typeInst = match($filiere['inst_type'] ?? '') {
    'faculte'          => 'Faculté universitaire',
    'institut_superieur' => 'Institut Supérieur',
    'ecole'            => 'École Nationale / Grande École',
    'centre_prep'      => 'Centre Préparatoire',
    default            => 'Établissement universitaire',
};
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($filiere['titre']) ?> — EduGuide TN</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .inst-block {
            background: linear-gradient(135deg, var(--navy), var(--navy-mid));
            border-radius: var(--radius-md); padding: 18px 20px;
            margin-bottom: 14px;
        }
        .inst-block .inst-type {
            font-size:10px;font-weight:700;color:var(--gold);
            text-transform:uppercase;letter-spacing:0.8px;margin-bottom:6px;
        }
        .inst-block .inst-name {
            font-family:var(--font-display);font-size:1.05rem;
            font-weight:700;color:white;line-height:1.35;margin-bottom:4px;
        }
        .inst-block .inst-univ {
            font-size:12px;color:rgba(255,255,255,0.55);
        }
        .score-bar-wrap { margin:14px 0 0; }
        .score-bar-label { display:flex;justify-content:space-between;font-size:12px;color:rgba(255,255,255,0.6);margin-bottom:6px; }
        .score-bar { height:6px;background:rgba(255,255,255,0.15);border-radius:3px;overflow:hidden; }
        .score-bar-fill { height:100%;border-radius:3px;background:linear-gradient(to right,var(--gold),#f0c060); transition:width 1s ease; }
        .debouche-grid { display:grid;grid-template-columns:1fr 1fr;gap:10px; }
        @media(max-width:600px){.debouche-grid{grid-template-columns:1fr;}}
    </style>
</head>
<body>
<?php require('nav.php'); ?>

<!-- BANNER -->
<div class="detail-banner">
    <div style="position:relative;z-index:1;max-width:1240px;margin:0 auto;">
        <div class="breadcrumb">
            <a href="index.php">Accueil</a><span class="sep">/</span>
            <a href="filieres.php">Filières</a><span class="sep">/</span>
            <a href="filieres.php?domaine=<?= urlencode($filiere['domaine']) ?>"><?= htmlspecialchars($filiere['domaine']) ?></a><span class="sep">/</span>
            <span><?= htmlspecialchars(mb_substr($filiere['titre'],0,40)) ?>...</span>
        </div>
        <h1 style="font-family:var(--font-display);font-size:clamp(1.7rem,3.5vw,2.6rem);font-weight:700;color:white;margin-bottom:12px;">
            <?= $filiere['icon'] ?? '🎓' ?> <?= htmlspecialchars($filiere['titre']) ?>
        </h1>
        <!-- Institution badge -->
        <?php if($filiere['inst_nom']): ?>
        <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(212,168,83,0.15);border:1px solid rgba(212,168,83,0.35);border-radius:var(--radius-md);padding:8px 16px;margin-bottom:14px;">
            <span style="font-size:16px;">🏛️</span>
            <div>
                <div style="font-size:12px;font-weight:700;color:var(--gold);"><?= htmlspecialchars($filiere['inst_sigle'] ?? '') ?></div>
                <div style="font-size:11px;color:rgba(255,255,255,0.7);"><?= htmlspecialchars(mb_substr($filiere['inst_nom'],0,60)) ?><?= strlen($filiere['inst_nom'])>60?'…':'' ?></div>
            </div>
        </div>
        <?php endif; ?>
        <div class="tags-row">
            <span class="tag tag-red"><?= htmlspecialchars($filiere['domaine']) ?></span>
            <?php if($filiere['type_formation']): ?><span class="tag tag-gold"><?= htmlspecialchars($filiere['type_formation']) ?></span><?php endif; ?>
            <?php if($filiere['duree']): ?><span class="tag tag-blue">⏱ <?= $filiere['duree'] ?> ans</span><?php endif; ?>
            <?php if($filiere['langue']): ?><span class="tag tag-blue">🌐 <?= htmlspecialchars($filiere['langue']) ?></span><?php endif; ?>
            <span class="tag" style="background:rgba(212,168,83,0.18);color:var(--gold);border:1px solid rgba(212,168,83,0.3);">
                <?= $niveau['emoji'] ?> <?= $niveau['label'] ?>
            </span>
        </div>
    </div>
    <div style="position:absolute;inset:0;background:radial-gradient(circle at 70%,rgba(200,16,46,0.2),transparent 50%);pointer-events:none;"></div>
</div>

<!-- BODY -->
<div class="detail-body">
    <!-- Colonne principale -->
    <main>
        <?php getFlash(); ?>

        <!-- Description -->
        <div class="prose" style="background:white;border-radius:var(--radius-lg);padding:30px;border:1px solid var(--gray-mid);box-shadow:var(--shadow-sm);margin-bottom:28px;">
            <h2>À propos de cette formation</h2>
            <?php if($filiere['description_longue']): ?>
                <?= $filiere['description_longue'] ?>
            <?php else: ?>
                <p><?= htmlspecialchars($filiere['description']) ?></p>
            <?php endif; ?>

            <?php if($filiere['formule_calcul']): ?>
            <div style="margin-top:20px;padding:16px;background:var(--blue-light);border-radius:var(--radius-md);border-left:4px solid var(--blue);">
                <div style="font-size:12px;font-weight:700;color:var(--blue);margin-bottom:6px;">📐 FORMULE DE CALCUL DU SCORE</div>
                <code style="font-size:1.1rem;font-weight:700;color:var(--navy);background:transparent;">
                    <?= htmlspecialchars($filiere['formule_calcul']) ?>
                </code>
                <div style="font-size:12px;color:var(--blue);margin-top:6px;">
                    FG = Note Générale du Bac · M = Mathématiques · SVT = Sciences · AR = Arabe · ANG = Anglais · SP = Physique · Info = Informatique
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Institution -->
        <?php if($filiere['inst_nom']): ?>
        <div style="background:white;border-radius:var(--radius-lg);padding:28px;border:1px solid var(--gray-mid);box-shadow:var(--shadow-sm);margin-bottom:28px;">
            <h2 style="font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--text);margin-bottom:18px;">🏛️ Établissement dispensant la formation</h2>
            <div style="display:grid;grid-template-columns:auto 1fr;gap:20px;align-items:start;">
                <div style="width:64px;height:64px;background:linear-gradient(135deg,var(--navy),var(--navy-mid));border-radius:var(--radius-md);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;">🎓</div>
                <div>
                    <div style="font-size:11px;font-weight:700;color:var(--red);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:4px;"><?= $typeInst ?></div>
                    <div style="font-family:var(--font-display);font-size:1.25rem;font-weight:700;color:var(--text);margin-bottom:6px;"><?= htmlspecialchars($filiere['inst_nom']) ?></div>
                    <?php if($filiere['inst_sigle']): ?>
                    <div style="font-size:13px;color:var(--gray-text);font-weight:600;margin-bottom:6px;"><?= htmlspecialchars($filiere['inst_sigle']) ?></div>
                    <?php endif; ?>
                    <div style="font-size:13px;color:var(--text);">
                        🏛️ Rattaché à : <strong><?= htmlspecialchars($filiere['univ_nom'] ?? '') ?></strong>
                        <?php if($filiere['gouvernorat']): ?>— 📍 <strong><?= htmlspecialchars($filiere['gouvernorat']) ?></strong><?php endif; ?>
                    </div>
                    <?php if($filiere['code_orientation']): ?>
                    <div style="margin-top:8px;">
                        <span style="font-size:11px;background:var(--gold-light);color:#7A5A18;padding:3px 10px;border-radius:50px;font-weight:700;">
                            Code orientation : <?= htmlspecialchars($filiere['code_orientation']) ?>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if($filiere['inst_web'] || $filiere['site_web']): ?>
            <div style="margin-top:14px;">
                <a href="<?= htmlspecialchars($filiere['inst_web'] ?? $filiere['site_web']) ?>" target="_blank"
                   class="btn btn-sm" style="background:var(--blue-light);color:var(--blue);font-weight:700;">
                    🌍 Site officiel de l'établissement
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Matières enseignées -->
        <?php if(!empty($matieres)): ?>
        <div style="background:white;border-radius:var(--radius-lg);padding:28px;border:1px solid var(--gray-mid);box-shadow:var(--shadow-sm);margin-bottom:28px;">
            <h2 style="font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--text);margin-bottom:18px;">📚 Matières principales</h2>
            <div style="display:flex;flex-wrap:wrap;gap:10px;">
                <?php foreach($matieres as $mat): ?>
                <span class="chip chip-blue" style="font-size:13px;padding:8px 16px;"><?= htmlspecialchars($mat) ?></span>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Débouchés -->
        <?php if(!empty($debouches)): ?>
        <div style="background:white;border-radius:var(--radius-lg);padding:28px;border:1px solid var(--gray-mid);box-shadow:var(--shadow-sm);margin-bottom:28px;">
            <h2 style="font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--text);margin-bottom:18px;">💼 Débouchés professionnels</h2>
            <div class="debouche-grid">
                <?php foreach($debouches as $deb): ?>
                <div style="display:flex;align-items:center;gap:10px;padding:12px 16px;background:var(--gray-soft);border-radius:var(--radius-md);border:1px solid var(--gray-mid);">
                    <span style="color:var(--red);font-size:16px;flex-shrink:0;">✓</span>
                    <span style="font-size:14px;color:var(--text);font-weight:500;"><?= htmlspecialchars($deb) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Conditions d'admission -->
        <div style="background:white;border-radius:var(--radius-lg);padding:28px;border:1px solid var(--gray-mid);box-shadow:var(--shadow-sm);margin-bottom:28px;">
            <h2 style="font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--text);margin-bottom:18px;">📝 Conditions d'admission</h2>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div style="padding:18px;background:var(--red-light);border-radius:var(--radius-md);border:1px solid rgba(200,16,46,0.15);">
                    <div style="font-size:10px;font-weight:700;color:var(--red);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Score minimum requis</div>
                    <div style="font-family:var(--font-display);font-size:2rem;font-weight:700;color:var(--red);"><?= number_format($filiere['score_min'],1) ?></div>
                    <div style="font-size:12px;color:var(--red);opacity:0.7;">/ 210 points</div>
                </div>
                <div style="padding:18px;background:var(--gold-light);border-radius:var(--radius-md);border:1px solid rgba(212,168,83,0.2);">
                    <div style="font-size:10px;font-weight:700;color:#7A5A18;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Score moyen admis</div>
                    <div style="font-family:var(--font-display);font-size:2rem;font-weight:700;color:#7A5A18;"><?= number_format($filiere['score_moyen'] ?? $filiere['score_min'],1) ?></div>
                    <div style="font-size:12px;color:#7A5A18;opacity:0.7;">/ 210 points</div>
                </div>
            </div>
            <?php if($filiere['capacite']): ?>
            <div style="margin-top:14px;padding:14px 16px;background:var(--blue-light);border-radius:var(--radius-md);display:flex;align-items:center;gap:10px;">
                <span style="font-size:20px;">👥</span>
                <span style="font-size:14px;color:var(--blue);font-weight:600;">Capacité d'accueil : <strong><?= $filiere['capacite'] ?> places</strong> par an</span>
            </div>
            <?php endif; ?>
            <?php if($filiere['bac_requis'] && $filiere['bac_requis'] !== 'Toutes séries'): ?>
            <div style="margin-top:12px;padding:14px 16px;background:var(--gray-soft);border-radius:var(--radius-md);">
                <span style="font-size:13px;color:var(--text);font-weight:600;">🎓 Sections du bac acceptées : </span>
                <span style="font-size:13px;color:var(--gray-text);"><?= htmlspecialchars($filiere['bac_requis']) ?></span>
            </div>
            <?php endif; ?>
        </div>

        <!-- Filières similaires -->
        <?php if(!empty($similaires)): ?>
        <div style="margin-bottom:28px;">
            <h2 style="font-family:var(--font-display);font-size:1.4rem;font-weight:700;color:var(--text);margin-bottom:18px;">🔗 Filières similaires</h2>
            <div class="grid-3">
                <?php foreach($similaires as $s): ?>
                <a href="detail.php?id=<?= $s['id'] ?>" class="filiere-card" style="text-decoration:none;">
                    <div class="card-top <?= htmlspecialchars($s['couleur_classe'] ?? 'ct-def') ?>" style="height:100px;">
                        <div class="card-icon"><?= $s['icon'] ?? '🎓' ?></div>
                        <span class="card-score">≥ <?= number_format($s['score_min'],1) ?>/210</span>
                    </div>
                    <div class="card-body" style="padding:14px;">
                        <h4 style="font-family:var(--font-display);font-size:0.95rem;font-weight:700;color:var(--text);margin-bottom:4px;"><?= htmlspecialchars($s['titre']) ?></h4>
                        <p style="font-size:11px;color:var(--gray-text);">🏛️ <?= htmlspecialchars($s['inst_sigle'] ?? $s['univ_sigle'] ?? 'N/A') ?></p>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </main>

    <!-- Carte latérale -->
    <aside class="detail-sticky">
        <!-- Score & info card -->
        <div class="info-card">
            <div class="score-block">
                <div style="font-size:12px;opacity:0.8;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.5px;">Score minimum requis</div>
                <div class="score-big"><?= number_format($filiere['score_min'],1) ?></div>
                <div class="score-lbl">/ 210 points</div>
                <div style="margin-top:8px;background:rgba(255,255,255,0.15);border-radius:50px;padding:3px 12px;font-size:11px;font-weight:700;">
                    <?= $niveau['emoji'] ?> Niveau <?= $niveau['label'] ?>
                </div>
            </div>

            <div class="info-list">
                <?php if($filiere['inst_nom']): ?>
                <div class="info-row">
                    <div class="info-ico">🏛️</div>
                    <div>
                        <div style="font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:700;margin-bottom:2px;">Établissement</div>
                        <div style="font-size:12px;font-weight:600;"><?= htmlspecialchars($filiere['inst_sigle'] ?? mb_substr($filiere['inst_nom'],0,35).'…') ?></div>
                        <div style="font-size:11px;color:var(--gray-text);"><?= htmlspecialchars($filiere['univ_sigle'] ?? '') ?></div>
                    </div>
                </div>
                <?php elseif($filiere['univ_nom']): ?>
                <div class="info-row">
                    <div class="info-ico">🏛️</div>
                    <div>
                        <div style="font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:700;margin-bottom:2px;">Université</div>
                        <div style="font-size:13px;font-weight:600;"><?= htmlspecialchars($filiere['univ_nom']) ?></div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($filiere['gouvernorat']): ?>
                <div class="info-row">
                    <div class="info-ico">📍</div>
                    <div>
                        <div style="font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:700;margin-bottom:2px;">Région</div>
                        <div style="font-size:13px;font-weight:600;"><?= htmlspecialchars($filiere['gouvernorat']) ?><?= $filiere['region']?' ('.$filiere['region'].')':'' ?></div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($filiere['type_formation']): ?>
                <div class="info-row">
                    <div class="info-ico">🎓</div>
                    <div>
                        <div style="font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:700;margin-bottom:2px;">Type</div>
                        <div style="font-size:13px;font-weight:600;"><?= htmlspecialchars($filiere['type_formation']) ?></div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($filiere['duree']): ?>
                <div class="info-row">
                    <div class="info-ico">⏱️</div>
                    <div>
                        <div style="font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:700;margin-bottom:2px;">Durée</div>
                        <div style="font-size:13px;font-weight:600;"><?= $filiere['duree'] ?> ans</div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($filiere['formule_calcul']): ?>
                <div class="info-row">
                    <div class="info-ico">📐</div>
                    <div>
                        <div style="font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:700;margin-bottom:2px;">Formule score</div>
                        <div style="font-size:13px;font-weight:700;font-family:monospace;color:var(--navy);"><?= htmlspecialchars($filiere['formule_calcul']) ?></div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($filiere['code_orientation']): ?>
                <div class="info-row">
                    <div class="info-ico">🔢</div>
                    <div>
                        <div style="font-size:10px;color:var(--gray-text);text-transform:uppercase;font-weight:700;margin-bottom:2px;">Code orientation</div>
                        <div style="font-size:14px;font-weight:700;font-family:monospace;color:var(--red);"><?= htmlspecialchars($filiere['code_orientation']) ?></div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- CTA favoris -->
            <?php if(isLoggedIn()): ?>
                <form method="POST" style="margin-bottom:10px;">
                    <button type="submit" name="toggle_favori"
                            class="btn btn-full <?= $isFavori ? 'btn-outline' : 'btn-primary' ?>">
                        <?= $isFavori ? '❤️ Retirer des favoris' : '🤍 Ajouter aux favoris' ?>
                    </button>
                </form>
            <?php else: ?>
                <a href="connexion.php" class="btn btn-primary btn-full" style="margin-bottom:10px;">
                    🔐 Se connecter pour sauvegarder
                </a>
            <?php endif; ?>

            <a href="chatbot.php?prefill=<?= urlencode('Parle moi de la filière '.$filiere['titre']) ?>"
               class="btn btn-dark btn-full">
                🤖 Demander au Chatbot IA
            </a>

            <?php if($filiere['site_web'] || $filiere['inst_web']): ?>
            <a href="<?= htmlspecialchars($filiere['inst_web'] ?? $filiere['site_web']) ?>"
               target="_blank" class="btn btn-full"
               style="background:var(--blue-light);color:var(--blue);margin-top:10px;font-weight:700;">
                🌍 Site officiel
            </a>
            <?php endif; ?>
        </div>

        <!-- Widget similaire -->
        <div class="info-card" style="margin-top:18px;background:linear-gradient(135deg,var(--navy),var(--navy-mid));border:none;">
            <h4 style="font-family:var(--font-display);font-size:0.95rem;color:white;margin-bottom:12px;">🔍 Filières similaires</h4>
            <a href="filieres.php?domaine=<?= urlencode($filiere['domaine']) ?>"
               class="btn btn-gold btn-full btn-sm">
                Voir tout : <?= htmlspecialchars($filiere['domaine']) ?>
            </a>
        </div>
    </aside>
</div>

<?php require('footer.php'); ?>
</body>
</html>